# Kilau Quiz

Aplikasi quiz modern untuk siswa SD (kelas 4-6) dengan UI Bahasa Indonesia.

## Fitur
- **Pelajaran**: Matematika, IPAS, IPS, Bahasa Indonesia, Pancasila, Pengetahuan Umum
- Karakter anime yang bereaksi
- Suara jawaban + mute
- Feedback benar/salah (hijau/merah)
- Admin panel (password rahasia)
- **Kilau Quiz AI** → generate pertanyaan otomatis

## Cara Pakai
1. Extract zip
2. Buka `index.html` di browser
3. Admin: klik tombol ADMIN di pojok kanan atas

## Kilau Quiz AI
Di admin panel → klik **🤖 Kilau Quiz AI**
- Pilih pelajaran & kesulitan
- Klik "Buat Pertanyaan dengan AI"
- Preview → Simpan ke database

Dibuat untuk pengalaman belajar yang menyenangkan.
